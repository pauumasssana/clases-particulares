// Este fichero se le da al alumno
#ifndef COLORES_H
#define	COLORES_H

void printf_color_num(int num); // Cambia al color correspomdiente a este num
void printf_reset_color();	// Imprimir en color por defecto del terminal
void printf_color_negrita();	// Imprimir en color por defecto pero en negrita

#endif	/* COLORES_H */

