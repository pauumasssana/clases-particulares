#include <stdio.h>
#define DIM 10

int main()
{
    int vdesord[DIM]={3, 56, 23, 109, 238, 32, 56, 67, 10, 88};
    int i, valor;
  
    /* Complete el programa */










}

