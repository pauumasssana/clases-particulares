#include <stdio.h>
#define DIM 10

int main()
{
    int vorden[DIM]={238, 109, 88, 67, 56, 56, 32, 23, 10, 3 };
    int i, valor;
  
    /* Complete el programa */










}

