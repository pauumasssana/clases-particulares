#include <stdio.h>
#define DIM 10

typedef struct {
  	int nelem;       /* numero de elementos almacenados en el campo vector */
 	int vector[DIM]; /* vector de enteros ordenado de menor a mayor */
} t_vector_int;

int main()
{
    t_vector_int vect={6,{3, 10,  23, 56, 109, 238}};
  
    /* Complete el programa */

}

