#include <stdio.h>
#define DIM 100

typedef struct {
  	char palo;  /* b-bastos, c-copas, e-espadas, o-oros */
 	int  valor; /* valor entre 1 y 12 */
} t_carta;

typedef struct {
   	int ncartas;          /* numero de cartas en la baraja */
   	t_carta cartas[DIM];   /* cartas que forman la baraja */
} t_baraja;

int main()
{
    t_baraja b1;
  
    /* Complete el programa */




}

