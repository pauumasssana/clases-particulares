#include <stdio.h>

int main() {
    int a = 0;
    int b = 2;

    /* Punto de parada para depuraci�n */

    a = 10;
    a = a + 4;

    printf("\n a = %d    b = %d \n", a, b);
}
