#include <stdio.h>
#include "colours.h"	
#include "azar.h"	

int main()
{
 // Declare aqui las variables necesarias


  inicializar_azar();		// Inicializa la semilla del generador de numeros aleatorio

 // Escriba a partir de aqui el codigo del programa

}
