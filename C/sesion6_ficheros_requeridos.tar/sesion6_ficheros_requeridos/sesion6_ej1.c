#include <stdio.h>
#define VACIA -1
#define N 10

typedef struct {
   int num, den;   // numerador y denominador
}tfracciones;

int main()
{
	// Aqui van las declaraciones de las variables m1, sudoku y mat_frac
    
    
    
    
    
}

