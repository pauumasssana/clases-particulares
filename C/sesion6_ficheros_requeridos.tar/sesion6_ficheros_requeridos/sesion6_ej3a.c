#include <stdio.h>
#define N 10

typedef struct
{
   int fils, cols;  // numero de filas y columnas de la matriz (1<=fil,col<=N)
   unsigned int mat[N][N];   // elementos de la matriz de naturales
}tmatriz;

int main()
{
    tmatriz m1, m2, msuma;

    /* Complete el programa */
}

